This program comes with absolutely no warranty. use at your own risk.

read readme.compilation for information on compiling this code yourself

the standard builds of this program contain 4 bots:
- "Bworld": an irc operator service bot simlar to undernets UWorld.
- "auth": is an authentication service used to authenticate to other bots
- "channel": is a channel service bot similar to quakenets Q and L 
- "connect4": allows users to play the game connect4

It is designed to be used with beware ircd, but should link to ircu (version 
2.10.10/11) as well. It has also been tested with asuka (quakenets ircd).

when the program runs, it is invisible: it has no window or icon.

==================
before you run the services, read and edit the ini files.


bewareserv.ini: contains settings for the services core, how to link to the 
server etc.

- servername: choose a name for the services server, which is not used by any other server on the net, like services.yournet.net, bworld.yournet.net, etc.
- servernum: choose a numeric (0-4095) which is not used by any other server on the net.
- autosave: if nonzero, ini files will be written every n seconds (they will also be written on shutdown)
- operchannel: the channel in which the services will log actions


don't change the NTservice setting manually, but instead use "bserv install" or "bserv uninstall" to use the program as NT service.

startbots.ini: lists which bots should be loaded on startup

bworld.ini: contains settings for the BWorld bot.

- operchannel: the channel in which the bot will log actions of operators.
- firewall: if set, the bot will not send any replies to who is not IRC operator, or is not logged in.

if the userid or info field is not set, the default from bewareserv.ini will be used instead.

note: even if you change the nick of the bot, it is still identified as "bworld" for internal things, for example explained later in this text.


auth.ini: contains settings for the auth bot.

- mailserver: the address of the mailserver used to send emails for account registration. on the unix version, use if possible a mailserver on the local machine or LAN, because it blocks while connecting to the mailserver (only while connecting to the mailserver not while sending the mail).

Note: as you can probabbly see auth's default nick is A. if the userid or info field is not set, the default from bewareserv.ini will be used instead.
note: even if you change the nick of the bot, it is still identified as "auth" for internal things, for example explained later in this text.


accounts.ini: contains the user accounts which are used globablly (bworld has the option to use a seperate accounts file which will be used by default if upgrading but not on a new install)
in the standard distribution this contains 1 account.
username: example, password: example. note you must be oper to login to it, for security reasons.

you can either edit the file now or edit the account online later. you can fill in the password as plaintext (provided it doesn't match the length of one of the crypted formats 13 or 24 chars), but it will be crypted the next time this file is written. the default user has level 1000. users with levels lower than 1000 can only edit/create/delete accounts of those with levels lower than themselves. 

authmail.txt: Contains the mail sent when an account is created if emailreg is on. The default one should make the format obvious.

requestpassmail: contains the mail sent when requestpassword is used (only possible when emailreg is on). The default one should make the format obvious.

================
to start services:

on windows, run bserv.exe.

on linux, change to the directory containing the services, then type:
./bserv &




commands needed to add an account:

ADDUSER <idnick> <level>
MODUSER NEWPASS <idnick> <password>
MODUSER ADDMASK <idnick> <mask>

note: bworld calls theese ADDOPER and MODOPER for historicial reasons

administrative tasks, such as stopping/starting the bot, rehash, or shutdown 
of the services, can be done using the following commands (from DOS prompt, 
or using batch files)

the signal system is currently only supported on windows it is not hugely
secure as any local user can use it (but windows is not secure with multiple
local users anyway) i plan to implement something better for the unix port
based on named pipes in the future.

bewareserv signal <parameters>


RESTART [botname]
- restarts services (for bworld bot, this allows applying changed nick and 
  operchannel settings)

START [botname]
- starts the given bot

STOP [botname]
- stops the given bot

DIE
- shuts down the services, terminates program.

botname can currently be "bworld", "a" or empty - in which case it may apply 
to the services core as well.




list of BWorld commands:

LOGIN DEAUTH HELP MKPASSWD LUSERS WHOIS GLIST CHANINFO 
KILL GLINE UNGLINE REFRESHG LISTCHANNELS ADDCHANNEL 
DELCHANNEL INVITE MODE KICKALL OPALL DEOPALL CLEARMODES 
CLEARBANS OP DEOP SETTIME QUOTE REHASH SAVE RESTART 
DIE DIEBOT CHLEVEL CHCOMNAME MEM EXCEPTIONLIST ADDEXCEPTION 
DELEXCEPTION ADDOPER DELOPER MODOPER OPERLIST OPERINFO 


/msg bworld HELP gives the commands which you can access.

short explanation of commands:

MKPASSWD    : gives encrypted password, compatible with beware irc services, 
              and beware ircd O:lines.
CHANINFO    : gives all info about a channel, modes, users on the channel, 
              bans, etc.
REFRESHG    : re-sends all G-lines. use to update a server which linked, or is 
              restarted.
LISTCHANNELS,
ADDCHANEL   ,
DELCHANNEL  : list of channels which are kept open by the BWorld bot (you still
              need OP or MODE access to become op yourself)
EXCPTIONLIST,
ADDEXCEPTION,
DELEXCEPTION: list of IP masks which have a higher clone limit.
RESTART     : restart the bworld bot
DIE         : stop services program
DIEBOT      : stop bworld bot
CHLEVEL     : change the access level for a command
CHCOMNAME   : change the name of a command
SETTIME     : send a settime to sync the clock of all servers on the net
OPERLIST    : see a list of all oper accounts
OPERINFO    : see info about an oper account
SET         : change various configuration options (some, like nick, 
              operchannel, require restart of the bot, to apply)

The operation of A is similar to that of bworld but is has less commands and all admin commands are by default on level 900 (unlike bworld which has a spread of levels)

If the services stopped unintended (crashed), the file assert.log may have more information about it. this happens if the program encounters something which should not happen. you can send me email in that case, with the contents of the file, and, if possible, what you did to cause the error.
